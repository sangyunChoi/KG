import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64
import serial

class ArduinoLedControlNode(Node):
    def __init__(self):
        super().__init__('arduino_led_control_node')
        self.subscription = self.create_subscription(
            Int64,
            '/random_number',
            self.led_command_callback,
            10)
        
        # Arduino와 시리얼 통신 설정
        self.arduino = serial.Serial('/dev/ttyUSB0', 9600)

    def led_command_callback(self, msg):
        self.get_logger().info('I heard: "%d"' % msg.data)  # 수신한 숫자 출력
        
        if msg.data % 2 == 0:  # 짝수일 경우
            self.arduino.write(b'1')  # LED 켜기
            self.get_logger().info('Sent command to turn LED ON')
        else:  # 홀수일 경우
            self.arduino.write(b'0')  # LED 끄기
            self.get_logger().info('Sent command to turn LED OFF')

def main(args=None):
    rclpy.init(args=args)
    arduino_led_control_node = ArduinoLedControlNode()
    rclpy.spin(arduino_led_control_node)
    arduino_led_control_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
