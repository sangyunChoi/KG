import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64
import random
import time

class RandomNumberPublisher(Node):
    def __init__(self):
        super().__init__('random_number_publisher')
        self.publisher_ = self.create_publisher(Int64, '/random_number', 10)
        self.timer = self.create_timer(1.0, self.publish_random_number)  # 1초마다 랜덤 숫자 발행

    def publish_random_number(self):
        random_number = random.randint(1, 50)  # 1에서 50 사이의 랜덤 숫자 생성
        self.publisher_.publish(Int64(data=random_number))
        self.get_logger().info('Publishing: "%d"' % random_number)  # 발행된 숫자 출력

def main(args=None):
    rclpy.init(args=args)
    random_number_publisher = RandomNumberPublisher()
    rclpy.spin(random_number_publisher)
    random_number_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
