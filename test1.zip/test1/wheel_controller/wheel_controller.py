import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class WheelController(Node):
    def __init__(self):
        super().__init__('wheel_controller')

        # Publisher for each wheel
        self.wheel1_pub = self.create_publisher(Float64, 'wheel1_velocity', 10)
        self.wheel2_pub = self.create_publisher(Float64, 'wheel2_velocity', 10)
        self.wheel3_pub = self.create_publisher(Float64, 'wheel3_velocity', 10)
        self.wheel4_pub = self.create_publisher(Float64, 'wheel4_velocity', 10)

        # Timer to publish the velocity
        self.timer = self.create_timer(0.1, self.publish_wheel_velocity)

        # Set a constant velocity for the wheels
        self.wheel_velocity = 1.0  # 원하는 속도로 설정 (예: 1.0)

    def publish_wheel_velocity(self):
        # Publish the current velocity to each wheel
        msg = Float64()
        msg.data = self.wheel_velocity
        
        self.wheel1_pub.publish(msg)
        self.wheel2_pub.publish(msg)
        self.wheel3_pub.publish(msg)
        self.wheel4_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    wheel_controller = WheelController()
    rclpy.spin(wheel_controller)
    wheel_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()