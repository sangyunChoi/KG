from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Launch arguments
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    # Paths to URDF and RViz config
    package_name = 'test1'
    urdf_file_name = 'test1.urdf'
    
    # get_package_share_directory로 패키지의 공유 디렉터리 경로 가져오기
    urdf_path = os.path.join(get_package_share_directory(package_name), 'urdf', urdf_file_name)
    rviz_config_file = os.path.join(get_package_share_directory(package_name), 'config', 'rviz_config.rviz')

    return LaunchDescription([
        # Use simulation time argument
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation (Gazebo) clock if true'),

        # robot_state_publisher Node
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
            arguments=[urdf_path]),

        # joint_state_publisher_gui Node
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            parameters=[{'use_sim_time': use_sim_time}]),

        # RViz Node
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config_file]),

        # WheelController Node
        Node(
            package='test1',  # 패키지 이름을 적어주세요
            executable='wheel_controller',  # 실행할 노드 이름
            name='wheel_controller',
            output='screen',
        )
                # Wheel Controller Node
    ]
    )